A Pen created at CodePen.io. You can find this one at https://codepen.io/dminter/pen/pLomjq.

 That's definitely a wrong rapresentation of a NN, but it looks cool :D

Click to generate a new structure